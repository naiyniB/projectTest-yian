//生成代码的时候，生成一个随机数就行，不需要配置
//生成代码的时候，识别ContactForm组件，添加这个属性
export const FORM_SALT = "4355096838148";
